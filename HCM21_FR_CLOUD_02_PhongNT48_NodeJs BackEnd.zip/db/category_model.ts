export {};
const mongoose = require('mongoose')

//const ObjectID = require('mongodb').ObjectID;
const categorySchema = new mongoose.Schema({


    CategoryID:{
        type: Number,
        required: true
    },
    CategoryName:{
        type: String,
        required: true
    },
    Description:{
        type: String,
        required: true
    }
})

module.exports = mongoose.model('Categories',categorySchema,'Categories')
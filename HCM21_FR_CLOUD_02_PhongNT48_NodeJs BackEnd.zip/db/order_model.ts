export {};
const mongoose = require('mongoose')


const orderSchema = new mongoose.Schema({

    ProductID:{
        type:  mongoose.Schema.Types.ObjectId, ref: 'Products',
        required: true
    },
    Quantity:{
        type: Number,
        required: true
    },
    Price:{
        type: Number,
        required: true
    },
    OrderDate:{
        type: Date,
        required: true,
        default: Date.now
    }
})

module.exports = mongoose.model('Orders',orderSchema,'Orders')
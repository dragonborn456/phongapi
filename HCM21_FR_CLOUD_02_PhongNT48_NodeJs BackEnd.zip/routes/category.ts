export {};
const express = require('express')
const routerC = express.Router()
const mongoose = require('mongoose')
const category = require('../db/category_model')


routerC.get('/', async(req:any, res:any)=>{
    try{
    const categories = await category.find({})
    res.json(categories)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

routerC.get('/:id', async(req:any, res:any)=>{
    try{
    const categoriid = await category.findById(req.params.id)
    res.json(categoriid)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

routerC.post('/insert', async(req:any, res:any)=>{
    const categoriesI = new category({
        CategoryID: req.body.CategoryID,
        CategoryName: req.body.CategoryName,
        Description: req.body.Description
    })
    try
    {
        const insert = await categoriesI.save()
        res.json(insert)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

routerC.patch('/update/:id', async(req:any, res:any)=>{
    try{
    const categoriesU = await category.findByIdAndUpdate(req.params.id, req.body, { useFindAndModify: false })
    categoriesU.CategoryID = req.body.CategoryID,
    categoriesU.CategoryName = req.body.CategoryName,
    categoriesU.Description = req.body.Description
    const update = await categoriesU.save()
    res.json(update)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

routerC.delete('/delete/:id', async(req:any, res:any)=>{
    try{
    const categoriesD = await category.findByIdAndDelete(req.params.id)
    res.json(categoriesD)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})
module.exports = routerC
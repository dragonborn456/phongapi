export {};
const express = require('express')
const routerO = express.Router()
const mongoose = require('mongoose')
const order = require('../db/order_model')


routerO.get('/', async(req:any, res:any)=>{
    try{
        const orders = await order.find({}).populate('ProductID','ProductName')
    res.json(orders)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})


routerO.get('/:id', async(req:any, res:any)=>{
    try{
    const orderid = await order.findById(req.params.id).populate('ProductID','ProductName')
    res.json(orderid)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

routerO.post('/insert', async(req:any, res:any)=>{
    const orderesI = new order({
        ProductID: req.body.ProductID,
        Quantity: req.body.Quantity,
        Price: req.body.Price
    })
 
        const insert = await orderesI.save()
        res.json(insert)

})

routerO.patch('/update/:id', async(req:any, res:any)=>{
    try{
    const orderesU = await order.findByIdAndUpdate(req.params.id, req.body, { useFindAndModify: false })
    orderesU.ProductID = req.body.ProductID,
    orderesU.Quantity = req.body.Quantity,
    orderesU.Price = req.body.Price,
    orderesU.OrderDate = req.body.OrderDate
    const update = await orderesU.save()
    res.json(update)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

routerO.delete('/delete/:id', async(req:any, res:any)=>{
    try{
    const orderesD = await order.findByIdAndDelete(req.params.id)
    res.json(orderesD)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

module.exports = routerO
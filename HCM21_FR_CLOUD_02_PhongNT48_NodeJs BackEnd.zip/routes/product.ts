export {};
const express = require('express')
const routerP = express.Router()
const ObjectID = require('mongoose').Types.ObjectId
const product = require('../db/product_model')


//get data
routerP.get('/', async(req:any, res:any)=>{

    try{
        const products = await product.find({}).populate('CategoryID','CategoryName')
    res.json(products)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

//get data with id
routerP.get('/:id', async(req:any, res:any)=>{
    try{
    const productid = await product.findById(req.params.id).populate('CategoryID','CategoryName')
    res.json(productid)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

//update
routerP.post('/insert', async(req:any, res:any)=>{
    const productesI = new product({
        ProductID: req.body.ProductID,
        ProductName: req.body.ProductName,
        CategoryID: req.body.CategoryID,
        Quantity: req.body.Quantity,
        Price: req.body.Price,
        Discontinued: req.body.Discontinued
    })
    try{
        const insert = await productesI.save()
        res.json(insert)
    }
    catch(err)
    {
        res.send('Wrong attribute')
    }
})

routerP.patch('/update/:id', async(req:any, res:any)=>{
    try{
    const productesU = await product.findByIdAndUpdate(req.params.id, req.body, { useFindAndModify: false })
    productesU.ProductName = req.body.ProductName,
    productesU.Quantity = req.body.Quantity,
    productesU.Price = req.body.Price,
    productesU.Discontinued = req.body.Discontinued
    const update = await productesU.save()
    res.json(update)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

routerP.delete('/delete/:id', async(req:any, res:any)=>{
    try{
    const productesD = await product.findByIdAndDelete(req.params.id)
    res.json(productesD)
    }
    catch(err)
    {
        res.send('Lỗi')
    }
})

module.exports = routerP
export {};
const mongoose = require('mongoose')

const ObjectID = require('mongodb').ObjectID;
const orderSchema = new mongoose.Schema({
    _id:{
        type: ObjectID,
        auto: true
    },
    OrderID:{
        type: Number,
        required: true
    },
    CustomerID:{
        type: Number,
        required: true
    },
    EmployeeID:{
        type: Number,
        required: true
    },
    Product:{
        type: String,
        required: true
    },
    Price:{
        type: Number,
        required: true
    },
    OrderDate:{
        type: Date,
        required: true,
        default: Date.now
    }
})

module.exports = mongoose.model('order',orderSchema,'Orders')
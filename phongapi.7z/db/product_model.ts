export {};
const mongoose = require('mongoose')

const ObjectID = require('mongodb').ObjectID;
const productSchema = new mongoose.Schema({
    _id:{
        type: ObjectID,
        auto: true
    },
    ProductID:{
        type: Number,
        required: true
    },
    ProductName:{
        type: String,
        required: true
    },
    CategoryID:{
        type: Number,
        required: true
    },
    Quantity:{
        type: Number,
        required: true
    },
    Price:{
        type: Number,
        required: true
    },
    Discontinued:{
        type: Boolean,
        required: true,
        default: false
    }
})

module.exports = mongoose.model('product',productSchema,'Products')
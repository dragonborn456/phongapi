const mongoose = require('mongoose')
const express = require('express')
const app = express();
const port = 8000;


const url = 'mongodb+srv://phong99:Phong123456@phong-pco-cluster.epy73.mongodb.net/phongpco?retryWrites=true&w=majority'
mongoose.connect(url)
const conn = mongoose.connection
conn.on('open',()=>{
    console.log('phong-pco connected')
})


app.use(express.json())
const categoryC = require('./routes/category')
const productP = require('./routes/product')
const orderO = require('./routes/order')

app.use('/category', categoryC)
app.use('/product', productP)  
app.use('/order', orderO)  

app.get('/api/', (req:any, res:any) => {
  res.send({message: 'Hello World!'})
});


app.listen(port, () => {
  console.log(`App của Phong đã nghe ${port}!`)
});